A student resource repository

Create a mysql database with the following credentinals without the " " :

username = "root"
password = ""
database name= "Resmo"

and then import the "Resmo.sql" script


default server name -"localhost"

to open the data entry portal open "portal_1996.php"